<?php

class ControladorPLantilla{

    public function plantilla(){

		include "vistas/plantilla.php";

	}
}
<?php

require_once "controlador/plantilla.controlador.php";
require_once "controlador/jugador.controlador.php";

require_once "modelo/jugador.modelo.php";

$plantilla = new ControladorPLantilla();
$plantilla->plantilla();